// Global variables to store matrices for the Banker's Algorithm
let allocation, maximum, available, need;

/* ================= Generate Tables for Input ================= */

function generateTables() {
    const p = parseInt(document.getElementById("processes").value);
    const r = parseInt(document.getElementById("resources").value);

    let html = `<h3>Enter Allocation Matrix</h3>` + generateTable("allocation", p, r) +
        `<h3>Enter Maximum Matrix</h3>` + generateTable("maximum", p, r) +
        `<h3>Enter Available Resources</h3>` + generateTable("available", 1, r);

    document.getElementById("matrixContainer").innerHTML = html;

    let requestHtml = `<label>Process ID:</label> <input type="number" id="requestProcess" min="0" max="${p - 1}" value="0">`;
    requestHtml += `<h3>Enter Request</h3>` + generateTable("request", 1, r);

    document.getElementById("requestContainer").innerHTML = requestHtml;

    // Clear previous results
    document.getElementById("result").innerText = "";
    document.getElementById("requestResult").innerText = "";
    document.getElementById("needMatrix").innerHTML = "";
}

function generateTable(id, rows, cols) {
    let html = `<table id="${id}"><tr>`;
    for (let i = 0; i < cols; i++) html += `<th>R${i}</th>`;
    html += `</tr>`;
    for (let i = 0; i < rows; i++) {
        html += `<tr>`;
        for (let j = 0; j < cols; j++) {
            html += `<td><input type="number" value="0"></td>`;
        }
        html += `</tr>`;
    }
    html += `</table>`;
    return html;
}

/* ================= Banker's Algorithm ================= */

function runBankersAlgorithm() {
    const p = parseInt(document.getElementById("processes").value);
    const r = parseInt(document.getElementById("resources").value);

    allocation = getMatrixData("allocation", p, r);
    maximum = getMatrixData("maximum", p, r);
    available = getMatrixData("available", 1, r)[0];

    need = calculateNeedMatrix(maximum, allocation, p, r);
    renderNeedMatrix(); // Render Need matrix visually

    let safeSequence = [];
    let finish = new Array(p).fill(false);
    let work = available.slice();
    let count = 0;

    while (count < p) {
        let found = false;
        for (let i = 0; i < p; i++) {
            if (!finish[i]) {
                let canAllocate = true;
                for (let j = 0; j < r; j++) {
                    if (need[i][j] > work[j]) {
                        canAllocate = false;
                        break;
                    }
                }
                if (canAllocate) {
                    for (let j = 0; j < r; j++) work[j] += allocation[i][j];
                    safeSequence.push(i);
                    finish[i] = true;
                    found = true;
                    count++;
                }
            }
        }
        if (!found) {
            document.getElementById("result").innerText = "System is in an UNSAFE state!";
            return;
        }
    }

    document.getElementById("result").innerText = `System is in a SAFE state. Safe Sequence: ${safeSequence.map(x => `P${x}`).join(" -> ")}`;
}

/* ================= Resource Request Handling ================= */

function handleResourceRequest() {
    const p = parseInt(document.getElementById("requestProcess").value);
    const r = parseInt(document.getElementById("resources").value);
    let request = getMatrixData("request", 1, r)[0];

    for (let i = 0; i < r; i++) {
        if (request[i] > need[p][i]) {
            document.getElementById("requestResult").innerText = `Process P${p} requested more than its need! Request Denied.`;
            return;
        }
        if (request[i] > available[i]) {
            document.getElementById("requestResult").innerText = `Not enough available resources! Request Denied.`;
            return;
        }
    }

    // Temporarily allocate requested resources
    for (let i = 0; i < r; i++) {
        available[i] -= request[i];
        allocation[p][i] += request[i];
        need[p][i] -= request[i];
    }

    let tempResult = document.getElementById("result").innerText;
    runBankersAlgorithm();

    if (document.getElementById("result").innerText.includes("UNSAFE")) {
        // Rollback if system is unsafe
        for (let i = 0; i < r; i++) {
            available[i] += request[i];
            allocation[p][i] -= request[i];
            need[p][i] += request[i];
        }
        document.getElementById("requestResult").innerText = `Request would lead to an UNSAFE state! Request Denied.`;
        document.getElementById("result").innerText = tempResult;
    } else {
        document.getElementById("requestResult").innerText = `Request Granted! System remains in a SAFE state.`;
        updateTables(); // Update visible tables
    }
}

/* ================= Utility Functions ================= */

function getMatrixData(id, rows, cols) {
    let table = document.getElementById(id);
    let matrix = [];
    for (let i = 1; i <= rows; i++) {
        let row = [];
        for (let j = 0; j < cols; j++) {
            row.push(parseInt(table.rows[i].cells[j].children[0].value) || 0);
        }
        matrix.push(row);
    }
    return matrix;
}

function calculateNeedMatrix(maximum, allocation, p, r) {
    return maximum.map((row, i) => row.map((val, j) => val - allocation[i][j]));
}

function updateTables() {
    const p = allocation.length;
    const r = available.length;

    // Update the Allocation and Available matrices
    for (let i = 0; i < p; i++) {
        for (let j = 0; j < r; j++) {
            document.getElementById("allocation").rows[i + 1].cells[j].children[0].value = allocation[i][j];
        }
    }

    for (let j = 0; j < r; j++) {
        document.getElementById("available").rows[1].cells[j].children[0].value = available[j];
    }

    renderNeedMatrix();
}

function renderNeedMatrix() {
    if (!need) return;
    let html = `<h3>Need Matrix</h3><table><tr>`;
    const r = need[0].length;
    for (let j = 0; j < r; j++) html += `<th>R${j}</th>`;
    html += `</tr>`;
    for (let i = 0; i < need.length; i++) {
        html += `<tr>`;
        for (let j = 0; j < r; j++) {
            html += `<td>${need[i][j]}</td>`;
        }
        html += `</tr>`;
    }
    html += `</table>`;
    document.getElementById("needMatrix").innerHTML = html;
}
