// Global variables to store matrices for the Banker's Algorithm
let allocation, maximum, available, need;

/* ================= Generate Tables for Input ================= */

/**
 * Generates input tables for Allocation, Maximum, and Available Resources.
 * It also sets up the request table for additional resource requests.
 */
function generateTables() {
    const p = parseInt(document.getElementById("processes").value); // Number of processes
    const r = parseInt(document.getElementById("resources").value); // Number of resource types
    
    // Generate tables for Allocation, Maximum, and Available resources
    let html = `<h3>Enter Allocation Matrix</h3>` + generateTable("allocation", p, r) +
               `<h3>Enter Maximum Matrix</h3>` + generateTable("maximum", p, r) +
               `<h3>Enter Available Resources</h3>` + generateTable("available", 1, r);
    
    document.getElementById("matrixContainer").innerHTML = html;

    // Generate table for resource request input
    let requestHtml = `<label>Process ID:</label> <input type="number" id="requestProcess" min="0" max="${p - 1}" value="0">`;
    requestHtml += `<h3>Enter Request</h3>` + generateTable("request", 1, r);
    
    document.getElementById("requestContainer").innerHTML = requestHtml;
}

/**
 * Helper function to generate an HTML table dynamically.
 * @param {string} id - The ID of the table.
 * @param {number} rows - Number of rows.
 * @param {number} cols - Number of columns.
 * @returns {string} - The generated HTML table as a string.
 */
function generateTable(id, rows, cols) {
    let html = `<table id="${id}"><tr>`;
    for (let i = 0; i < cols; i++) html += `<th>R${i}</th>`; // Table header for resources
    html += `</tr>`;
    
    // Generate input fields inside the table
    for (let i = 0; i < rows; i++) {
        html += `<tr>`;
        for (let j = 0; j < cols; j++) {
            html += `<td><input type="number" value="0"></td>`;
        }
        html += `</tr>`;
    }
    html += `</table>`;
    return html;
}

/* ================= Banker's Algorithm ================= */

/**
 * Executes the Banker's Algorithm to determine if the system is in a safe state.
 */
function runBankersAlgorithm() {
    const p = parseInt(document.getElementById("processes").value); // Number of processes
    const r = parseInt(document.getElementById("resources").value); // Number of resources

    // Fetch matrices from the input fields
    allocation = getMatrixData("allocation", p, r);
    maximum = getMatrixData("maximum", p, r);
    available = getMatrixData("available", 1, r)[0]; // Available resources as a single array

    // Calculate the Need matrix
    need = calculateNeedMatrix(maximum, allocation, p, r);
    let safeSequence = [];

    // Initialization for the Banker's Algorithm
    let finish = new Array(p).fill(false); // Track finished processes
    let work = available.slice(); // Work vector (copy of available)
    let count = 0;

    // Attempt to find a safe sequence
    while (count < p) {
        let found = false;
        for (let i = 0; i < p; i++) {
            if (!finish[i]) { // If process is not finished
                let canAllocate = true;
                
                // Check if process's need can be satisfied with available resources
                for (let j = 0; j < r; j++) {
                    if (need[i][j] > work[j]) {
                        canAllocate = false;
                        break;
                    }
                }

                // If allocation is possible, execute process
                if (canAllocate) {
                    for (let j = 0; j < r; j++) work[j] += allocation[i][j]; // Release resources
                    safeSequence.push(i); // Add process to safe sequence
                    finish[i] = true; // Mark process as finished
                    found = true;
                    count++;
                }
            }
        }

        // If no process was found that can be allocated, system is unsafe
        if (!found) {
            document.getElementById("result").innerText = "System is in an UNSAFE state!";
            return;
        }
    }

    // Display the safe sequence
    document.getElementById("result").innerText = `System is in a SAFE state. Safe Sequence: ${safeSequence.map(x => `P${x}`).join(" -> ")}`;
}

/* ================= Resource Request Handling ================= */

/**
 * Handles additional resource requests from a process and checks if the request can be granted.
 */
function handleResourceRequest() {
    const p = parseInt(document.getElementById("requestProcess").value); // Requested process
    const r = parseInt(document.getElementById("resources").value); // Number of resources
    let request = getMatrixData("request", 1, r)[0]; // Get requested resources

    // Check if the request is valid
    for (let i = 0; i < r; i++) {
        if (request[i] > need[p][i]) {
            document.getElementById("requestResult").innerText = `Process P${p} requested more than its need! Request Denied.`;
            return;
        }
        if (request[i] > available[i]) {
            document.getElementById("requestResult").innerText = `Not enough available resources! Request Denied.`;
            return;
        }
    }

    // Temporarily allocate requested resources
    for (let i = 0; i < r; i++) {
        available[i] -= request[i];
        allocation[p][i] += request[i];
        need[p][i] -= request[i];
    }

    // Run the Banker's Algorithm to check if system remains safe
    let tempResult = document.getElementById("result").innerText;
    runBankersAlgorithm();
    
    // If system becomes unsafe, rollback allocation
    if (document.getElementById("result").innerText.includes("UNSAFE")) {
        for (let i = 0; i < r; i++) {
            available[i] += request[i];
            allocation[p][i] -= request[i];
            need[p][i] += request[i];
        }
        document.getElementById("requestResult").innerText = `Request would lead to an UNSAFE state! Request Denied.`;
        document.getElementById("result").innerText = tempResult;
    } else {
        document.getElementById("requestResult").innerText = `Request Granted! System remains in a SAFE state.`;
    }
}

/* ================= Utility Functions ================= */

/**
 * Retrieves numerical data from an HTML table.
 * @param {string} id - The ID of the table.
 * @param {number} rows - Number of rows in the table.
 * @param {number} cols - Number of columns in the table.
 * @returns {Array} - The extracted matrix data.
 */
function getMatrixData(id, rows, cols) {
    let table = document.getElementById(id);
    let matrix = [];
    
    for (let i = 1; i <= rows; i++) {
        let row = [];
        for (let j = 0; j < cols; j++) {
            row.push(parseInt(table.rows[i].cells[j].children[0].value) || 0);
        }
        matrix.push(row);
    }
    return matrix;
}

/**
 * Calculates the Need matrix by subtracting Allocation from Maximum.
 * @param {Array} maximum - The Maximum matrix.
 * @param {Array} allocation - The Allocation matrix.
 * @param {number} p - Number of processes.
 * @param {number} r - Number of resource types.
 * @returns {Array} - The computed Need matrix.
 */
function calculateNeedMatrix(maximum, allocation, p, r) {
    return maximum.map((row, i) => row.map((val, j) => val - allocation[i][j]));
}
